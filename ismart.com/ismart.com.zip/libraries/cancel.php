<?php

function iloveyoubaybe($num_ber,$start){
    $result = ceil($num_ber/$start);
    return $result;
}

?>