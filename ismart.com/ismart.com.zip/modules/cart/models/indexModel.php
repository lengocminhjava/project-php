<?php
function get_list_product_mvc_by_id($id)
{
  $result = db_fetch_array("SELECT *FROM `tbl_products` WHERE `id`={$id}");
  return $result;
}
function get_list_city()
{
  return db_fetch_array("SELECT * FROM `tbl_conscious`");
}
function list_city($id)
{
  return db_fetch_array("SELECT * FROM `tbl_district` WHERE `id_category` = {$id}");
}
