<?php
function construct()
{
  load_model('index');
}
function showAction()
{

  // load('helper','product_detail');
  $list_add = list_product_mvc();
  $data['list_add'] = $list_add;
  load_view('show', $data);
}
function addAction()
{

  load_view('add');
}
function deleteAction()
{
  $id = $_GET['id'];
  delete_cart($id);
  redirect("?mod=cart&controller=index&action=show");
}
function updateAction()
{
  $id = $_POST['id'];
  load_view('update');
}
function checkAction()
{
  $list_add = list_product_mvc();
  $data['list_add'] = $list_add;
  load_view('check', $data);
}
function qtyAction()
{

  load_view('qty');
}
function checkoutAction()
{
  load('lib', 'email');
  $list_order  =  $_SESSION['cart']['buy'];
  $list_city = get_list_city();
  global $error, $success;
  if (isset($_POST['order'])) {
    $error = array();
    $success = array();
    if (empty($_POST['fullname'])) {
      $error['fullname'] = "Không được bỏ trống trường này";
    } else {
      $fullname = $_POST['fullname'];
    }
    if (empty($_POST['email'])) {
      $error['email'] = "Bạn cần nhập thông tin";
    } else {
      if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $error['email'] = "Bạn nhập sai định dạng";
      } else
        $email = $_POST['email'];
    }
    if (empty($_POST['number'])) {
      $error['number'] = "Không được bỏ trống trường này";
    } else {
      if (is_numeric($_POST['number']) == FALSE) {
        $error['number'] = "Không phải là kiểu số";
      } else
        $number = $_POST['number'];
    }
    if (empty($_POST['phone_number'])) {
      $error['phone_number'] = "Không được bỏ trống tên đăng nhập";
    } else {
      if (!is_phone($_POST['phone_number'])) {
        $error['phone_number'] = "Số điện thoại không đúng";
      } else {
        $phone_number = $_POST['phone_number'];
      }
    }
    if ($_POST['select_city'] == 999) {
      $error['select_city'] = "Vui lòng chọn";
    } else {
      $city = $_POST['select_city'];
    }
    if ($_POST['select_district'] == 1) {
      $error['select_district'] = "Vui lòng chọn";
    } else {
      $district = $_POST['select_district'];
    }
    if (empty($_POST['commune'])) {
      $error['commune'] = "Không được bỏ trống trường này";
    } else {
      $commune = $_POST['commune'];
    }
    if (!empty($_POST['street'])) {
      $street = $_POST['street'];
    }
    if (!empty($_POST['notes'])) {
      $notes = $_POST['notes'];
    }
    if (empty($error)) {
      $list_order  =  $_SESSION['cart']['buy'];
      foreach ($list_order as $item) {

        $content = "
        <body>
            <div id='wrapper2'>
                <h1>Cảm ơn quý khách đã đặt hàng tại ismart</h1>
                <p class='highlight'>ismart rất vui thông báo đơn hàng #11222 đã được tiếp nhận và đang trong quá trình xử lí ismart sẽ thông báo đến quý khách ngay khi đơn hàng chuẩn bị được giao</p>
                <div class='text'><span>Thông tin đơn hàng #11222</span> (ngày <?php echo date('m/d/y G.i:s<br>', time()) ?>)</div>
                <div class='order'>
                    <div class='information'>
                        <p class='tt'>Thông tin thanh toán</p>
                        <p>Lê Ngọc Minh</p>
                        <p class='e'> <a href=''>minhokmen1@gmail.com</a> </p>
                        <p>Số điện thoại 0388371035</p>
                    </div>
                    <div class='logo'> <img src='https://www.ismart.org.br/wp-content/uploads/2022/01/LOGO-ismart.png' /></div>
                    <div class='more'>
                        <p class='tt'>Địa chỉ giao hàng</p>
                        <p class='adress'>Tòa nhà 115 lạc Hồng,Ngoại giao đoàn bắc Từ Liêm ,Hà Nội ,phường Xuân Táo,Băc Từ Liêm ,Hà Nội , Việt Nam</p>
                    </div>
                </div>
                <div class='show'>
                    <table>
        
                        <tr>
                            <th>Mã sản phẩm</th>
                            <th>Ảnh sản phẩm</th>
                            <th>Tên sản phẩm</th>
                            <th>Giá sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                        </tr>
        
                        <tr>
                            <td>Mã sản phẩm</td>
                            <td class='thumb'><img src='../admin/{$item['thumb']}' alt=''> </td>
                            <td> {$item['qty']} </td>
                            <td>{$item['price']}</td>
                            <td class='nb'> {$item['code']}</td>
                            <td></td>
                        </tr>
        
                    </table>
                </div>
                <div class='end'>
                    <p><strong>Phương thức thanh toán:</strong>Thanh toán tiền mặt khi nhận hàng</p>
                    <p><strong>Thời gian giao dự kiến:</strong>Sau từ 2 - 5 ngày kể từ khi giao hàng</p>
                    <p><strong>Phí vận chuyển:</strong>19.000đ</p>
                </div>
        
            </div>
        </body>
        
        </html>
      ";
      }
      send_mail($email, 'Fail', 'check', $content);
    }
  }
  $data = array(
    'list_order' => $list_order,
    'list_city' => $list_city
  );
  load_view('checkout', $data);
}
function updateAjaxAction()
{
  $id = (int)$_POST['id'];
  $list_city = list_city($id);
  $output = "";
  if (!empty($list_city)) {
    foreach ($list_city as $item) {
      $output .=
        '<option id="district">' . $item['name'] . '</option> ';
    }
  } else {
    $output .= '<option id="district">vui lòng chọn</option>';
  }
  $data = array(
    'output' => $output
  );

  echo json_encode($data);
}
function buy_nowAction()
{
  $id = $_GET['id'];
  add_cart_mvc($id);
  $list_order  =  $_SESSION['cart']['buy'];
  $list_city = get_list_city();
  $data = array(
    'list_order' => $list_order,
    'list_city' => $list_city
  );
  load_view('checkout', $data);
}
function changeAction()
{
  $id = $_POST['id'];
  $qty = $_POST['qty'];
  $quantity = $_POST['quantity'];
  if ($qty > 0) {
    if (isset($_SESSION['cart']['buy']) && array_key_exists($id, $_SESSION['cart']['buy'])) {
      $qty = $_SESSION['cart']['buy'][$id]['qty'] + $qty;
      if ($qty > $quantity) {
        $qty = $quantity;
      }
    }
    $list_product_mvc_1 = get_list_product_mvc_by_id($id);
    //   show_array($list_product_mvc_1);
    foreach ($list_product_mvc_1 as $item) {
      // show_array($item);
      $_SESSION['cart']['buy'][$id] = array(
        'id' => $item['id'],
        'code' => $item['code'],
        'title' => $item['title_product'],
        'price' => $item['price'],
        'discount' => $item['discount'],
        'thumb' => $item['thumbnail'],
        'content' => $item['detail_product'],
        'num_qty' => $item['num_qty'],
        'qty' => $qty,
        'sub_total' => $item['price'] * $qty
      );
      // show_array($_SESSION['cart']['buy']);
    };
    update_cart_mvc();
  }
  $data = array(
    'qty' => $qty
  );
}
