<?php
// Kiểm tra $parent_id có =$id hay không nếu có thì return true , không thì false
//Tìm các giá trị của $parent_id = $parent_id;
